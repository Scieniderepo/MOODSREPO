# Gronkh.tv Stream-Archive

Kodi (XBMC) plugin for accessing the stream archive on gronkh.tv

Kodi 18.7 and 19.1 are tested and running. Other versions might work as well, but are not tested.
