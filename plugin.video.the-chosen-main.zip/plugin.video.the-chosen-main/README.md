# plugin.video.the-chosen
The Chosen unofficial video addon for Kodi.   Watch The Chosen right in kodi!

"We’re telling the story of Jesus in 7 seasons. We’ll bring our loaves and fishes, you bring yours by paying it forward, and together we’ll watch God work miracles."

![](resources/icon.jpg?raw=true)

Watch The Chosen at https://watch.angelstudios.com/thechosen

# Disclaimers

This unofficial is not affiliated with or specifically authorized by The Chosen or Angel Studios. LICENSE refers to the code for this addon ONLY. Images and video included with or displayed by this addon belong to others and are licensed differently.
