# plugin.video.byu-tv
Kodi plugin for BYUtv

The mission of BYUtv is to create purposeful, engaging viewing and listening experiences that entertain, inspire, uplift, and improve families and communities. Our vision is to be the family entertainment brand that young people want, parents trust, and families enjoy together.

![](resources/icon.png?raw=true)

Unofficial and not affiliated with or specifically authorized by BYUtv.
