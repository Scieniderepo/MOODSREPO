#MFB.ca KodiPlugin Matrix version
Media from nfb.ca website.

Features:
Get the latest content from the nfb.ca website.

<img src="resources/icon.png" width="40%">