# Changelog

## plugin.audio.ytmusic.exp-1.0~beta10

- Fix the handling of artist albums.

## plugin.audio.ytmusic.exp-1.0~beta9

- Workaround for 'ValueError' problem inside PyTube code.

## plugin.audio.ytmusic.exp-1.0~beta8

- Add support for OAuth (for YouTube).

## plugin.audio.ytmusic.exp-1.0~beta7

- Add possibility to provide 'raw' headers.
- Catch the JsonDecodeError for good.

## plugin.audio.ytmusic.exp-1.0~beta6

- Fix catch of exception for JsonDecodeError
- Catch VideoUnavailable exception

## plugin.audio.ytmusic.exp-1.0~beta5

- Update pytube to version `v23.0.0`
- Update ytmusicapi to version `0.21.0`
