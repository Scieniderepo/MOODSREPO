[![GitHub release](https://img.shields.io/github/release/jelly/plugin.video.fosdem.svg)](https://github.com/jelly/plugin.video.fosdem/releases)
[![Build status](https://github.com/jelly/plugin.video.fosdem/workflows/CI/badge.svg)](https://github.com/jelly/plugin.video.fosdem/actions)
[![Codecov status](https://img.shields.io/codecov/c/github/jelly/plugin.video.fosdem/master)](https://codecov.io/gh/jelly/plugin.video.fosdem/branch/master)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![Contributors](https://img.shields.io/github/contributors/jelly/plugin.video.fosdem.svg)](https://github.com/jelly/plugin.video.fosdem/graphs/contributors)


# plugin.video.fosdem

Kodi addon for Fosdem videos.
